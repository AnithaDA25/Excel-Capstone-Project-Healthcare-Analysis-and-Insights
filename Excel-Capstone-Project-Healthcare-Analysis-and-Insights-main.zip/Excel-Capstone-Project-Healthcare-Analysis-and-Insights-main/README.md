# Excel-Capstone-Project-Healthcare-Analysis-and-Insights
Capstone project analyzing healthcare data using Excel. Includes data cleaning, pivot tables, and dashboards to generate insights.
